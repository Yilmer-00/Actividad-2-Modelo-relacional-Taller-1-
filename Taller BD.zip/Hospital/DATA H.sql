-- creamos la data que contendra la base de datos o en la tabla de consulta de medico 
INSERT INTO Medico (Id_Medico, Nombre, Especialidad, Registro_Medico) VALUES
('M001', 'Dra. Laura Pérez', 'Cardiología', 'CRM12345'),
('M002', 'Dr. Javier Soto', 'Pediatría', 'CRM67890'),
('M003', 'Dra. Ana Torres', 'Medicina General', 'CRM11223');

-- creamos la data que contendra la base de datos o en la tabla de consulta de paciente
INSERT INTO Paciente (Id_Paciente, Nombre, Numero_Historia_Clinica, Direccion, Telefono) VALUES
('P001', 'Roberto García', 'HCL001', 'Calle Falsa 123', '555-1001'),
('P002', 'María López', 'HCL002', 'Avenida Central 45', '555-1002'),
('P003', 'Carlos Ruiz', 'HCL003', 'Carrera 7, #2-10', '555-1003');

-- creamos la data que contendra la base de datos o en la tabla de consulta del medico
INSERT INTO Cita (Id_Medico, Id_Paciente, Fecha, Hora) VALUES
-- Cita de Roberto con Dra. Pérez
('M001', 'P001', '2025-11-15', '10:00:00'), 
-- Cita de María con Dr. Soto
('M002', 'P002', '2025-11-15', '11:30:00'), 
-- Cita de Roberto con Dra. Torres
('M003', 'P001', '2025-11-16', '09:00:00'),
-- Cita de Carlos con Dra. Pérez 
('M001', 'P003', '2025-11-15', '14:00:00'); 