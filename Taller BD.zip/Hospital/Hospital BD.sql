-- creamos la base de datos para el hospital
CREATE DATABASE IF NOT EXISTS HospitalBD;
-- Uso de la base de datos
USE HospitalBD;

-- creamos la primera tabla independiente de medico segun el modelo MER
CREATE TABLE IF NOT EXISTS Medico (
    Id_Medico VARCHAR(10) PRIMARY KEY, 
    Nombre VARCHAR(100) NOT NULL,
    Especialidad VARCHAR(100),
    Registro_Medico VARCHAR(20) UNIQUE NOT NULL
);

-- creo la segunda tabla independiente del paciente segun el modelo MER
CREATE TABLE IF NOT EXISTS Paciente (
    Id_Paciente VARCHAR(10) PRIMARY KEY, 
    Nombre VARCHAR(100) NOT NULL,
    Numero_Historia_Clinica VARCHAR(20) UNIQUE NOT NULL,
    Direccion VARCHAR(150),
    Telefono VARCHAR(15)
);
-- y por ultimo la ultima tabla que es cita
CREATE TABLE IF NOT EXISTS Cita (
    Id_Cita INT PRIMARY KEY AUTO_INCREMENT, 
    Id_Medico VARCHAR(10) NOT NULL,        
    Id_Paciente VARCHAR(10) NOT NULL,    
    Fecha DATE NOT NULL,
    Hora TIME NOT NULL,
    
    -- Restricción para asegurar que un médico no tenga dos citas a la misma hora/fecha
    UNIQUE KEY uk_medico_fecha_hora (Id_Medico, Fecha, Hora),

    -- Definición de Clave Foránea a la tabla Medico
    CONSTRAINT fk_cita_medico
        FOREIGN KEY (Id_Medico) REFERENCES Medico(Id_Medico)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
        
    -- Definición de Clave Foránea a la tabla Paciente
    CONSTRAINT fk_cita_paciente
        FOREIGN KEY (Id_Paciente) REFERENCES Paciente(Id_Paciente)
        ON UPDATE CASCADE
        ON DELETE RESTRICT 
);