-- creamos la DATA para la consulta de cliente 
INSERT INTO Cliente (Codigo_Cliente, Nombre, Direccion) VALUES
('C001', 'Andrea Reyes', 'Calle 50 # 3A-12'),
('C002', 'Marcos López', 'Av. 20, Edificio Sol'),
('C003', 'Sofía Gómez', 'Carrera 15 # 45-6');

-- creamos la DATA para la consulta de producto
INSERT INTO Producto (Codigo_Producto, Nombre, Precio, Codigo_Postal) VALUES
('P101', 'Monitor LED 24"', 150.00, '25001'),
('P102', 'Teclado Mecánico', 45.50, '25001'),
('P103', 'Mouse Inalámbrico', 20.00, '11001'),
('P104', 'Disco SSD 1TB', 80.00, '11001');

-- creamos la DATA para la consulta de pedidos
INSERT INTO Pedidos (Codigo_Cliente, Fecha) VALUES
('C001', '2025-11-05'), -- Este será el Pedido 1
('C002', '2025-11-06'), -- Este será el Pedido 2
('C001', '2025-11-06'); -- Este será el Pedido 3

-- creamos la DATA para la consulta de detalle_pedido
INSERT INTO Detalle_Pedido (Codigo_Pedido, Codigo_Producto, Cantidad) VALUES
 -- Pedido 1: 1 Monitor
(1, 'P101', 1),
-- Pedido 1: 2 Teclados
(1, 'P102', 2),
 -- Pedido 2: 1 Mouse 
(2, 'P103', 1),
-- Pedido 3: 3 SSDs
(3, 'P104', 3), 
-- Pedido 3: 1 Teclado
(3, 'P102', 1); 