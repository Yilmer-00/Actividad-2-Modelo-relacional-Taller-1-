SELECT * FROM Cliente;
SELECT * FROM Producto;
SELECT * FROM Pedidos;
SELECT * FROM Detalle_Pedido;