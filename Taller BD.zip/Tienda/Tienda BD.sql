-- Creamos la base de datos una tienda en linea
CREATE DATABASE IF NOT EXISTS PedidosBD;
-- Uso de la base de datos
USE PedidosBD;

-- creamos la tabla del cliente 
CREATE TABLE IF NOT EXISTS Cliente (
    Codigo_Cliente VARCHAR(10) PRIMARY KEY, 
    Nombre VARCHAR(100) NOT NULL,
    Direccion VARCHAR(150)
);

-- ahora creamos la tabla Producto
CREATE TABLE IF NOT EXISTS Producto (
    Codigo_Producto VARCHAR(10) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Precio DECIMAL(10, 2) NOT NULL,
    Codigo_Postal VARCHAR(10)
);
-- creamos la tabla de pedidos
CREATE TABLE IF NOT EXISTS Pedidos (
    Codigo_Pedido INT PRIMARY KEY AUTO_INCREMENT, 
    Fecha DATE NOT NULL,
    Codigo_Cliente VARCHAR(10) NOT NULL, 
    
    -- Defino de Clave Foránea a la tabla Cliente
    CONSTRAINT fk_pedidos_cliente
        FOREIGN KEY (Codigo_Cliente) REFERENCES Cliente(Codigo_Cliente)
        ON UPDATE CASCADE
        ON DELETE RESTRICT --
);
-- aquie va la tabla detalle_pedido diferente a pedidos 
CREATE TABLE IF NOT EXISTS Detalle_Pedido (
    Codigo_Pedido INT NOT NULL,  
    Codigo_Producto VARCHAR(10) NOT NULL, 
    Cantidad INT NOT NULL,
    PRIMARY KEY (Codigo_Pedido, Codigo_Producto), 

    -- Luego definimos de Clave Foránea a la tabla Pedidos
    CONSTRAINT fk_detalle_pedido
        FOREIGN KEY (Codigo_Pedido) 
        REFERENCES Pedidos(Codigo_Pedido)
        ON UPDATE CASCADE
        ON DELETE CASCADE, 
        
    -- y  por ultimo defino la Clave Foránea a la tabla Producto
    CONSTRAINT fk_detalle_producto
        FOREIGN KEY (Codigo_Producto) REFERENCES Producto(Codigo_Producto)
        ON UPDATE CASCADE
        ON DELETE RESTRICT 
);

