-- le creamos la DATA para la consulta de usuario
INSERT INTO Usuario (Codigo_Usuario, Nombre, Direccion) VALUES
('U001', 'Ana Vega', 'Calle 10, #5-A'),
('U002', 'Marcos Ruiz', 'Avenida Central'),
('U003', 'Elena Soto', 'Carrera 4, #2-10');

-- le creamos la DATA para la consulta de usuario
INSERT INTO Libro (Codigo_Libro, Titulo, Autor) VALUES
('L101', 'Cien años de soledad', 'G. García Márquez'),
('L102', 'El Quijote', 'M. de Cervantes'),
('L103', 'Donde los árboles cantan', 'Laura Gallego');


INSERT INTO Prestamo (Codigo_Usuario, Codigo_Libro, Fecha_Prestamo, Fecha_Devolucion) VALUES
-- Ana devolvió Cien años...
('U001', 'L101', '2025-11-01', '2025-11-15'),
-- Marcos tiene Donde los árboles... (ACTIVO) 
('U002', 'L103', '2025-11-05', NULL),
-- Ana tiene El Quijote (ACTIVO)         
('U001', 'L102', '2025-11-08', NULL),
-- Elena tiene Cien años... (ACTIVO)          
('U003', 'L101', '2025-11-09', NULL);          