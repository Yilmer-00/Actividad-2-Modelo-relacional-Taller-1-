SELECT * FROM Usuario;
SELECT * FROM Libro;
SELECT * FROM Prestamo;