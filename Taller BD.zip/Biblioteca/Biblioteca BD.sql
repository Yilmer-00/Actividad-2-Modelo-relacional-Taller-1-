-- Creación de la base de datos del Biblioteca Y porque V3 pues voy muchos intentos
CREATE DATABASE IF NOT EXISTS BibliotecaV3BD;
-- Uso de la base de datos
USE BibliotecaV3BD;

-- creamos la tabla Usuario
CREATE TABLE IF NOT EXISTS Usuario (
    Codigo_Usuario VARCHAR(10) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Direccion VARCHAR(150)
);

-- luego la tabla Libro
CREATE TABLE IF NOT EXISTS Libro (
    Codigo_Libro VARCHAR(10) PRIMARY KEY, 
    Titulo VARCHAR(100) NOT NULL,
    Autor VARCHAR(100)
);

-- y por ultimo la Tabla Préstamo que es donde se relaciona todo
CREATE TABLE IF NOT EXISTS Prestamo (
    Codigo_Prestamo INT PRIMARY KEY AUTO_INCREMENT, 
    Codigo_Usuario VARCHAR(10) NOT NULL,          
    Codigo_Libro VARCHAR(10) NOT NULL,            
    Fecha_Prestamo DATE NOT NULL,
    Fecha_Devolucion DATE,
    
    -- Restricción para la Clave Foránea a Usuario
    CONSTRAINT fk_prestamo_usuario
        FOREIGN KEY (Codigo_Usuario) REFERENCES Usuario(Codigo_Usuario)
        ON UPDATE CASCADE
        ON DELETE RESTRICT, 
        
    -- Restricción para la Clave Foránea a Libro
    CONSTRAINT fk_prestamo_libro
        FOREIGN KEY (Codigo_Libro) REFERENCES Libro(Codigo_Libro)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);