-- hacemos la consulta para la base de datos de la universidad
SELECT * FROM Estudiante;
SELECT * FROM Profesores;
SELECT * FROM Cursos;
SELECT * FROM Inscribe;