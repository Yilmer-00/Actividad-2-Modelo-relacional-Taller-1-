-- creamos la base de datos de el sistemaAcademico o de la universidad
CREATE DATABASE IF NOT EXISTS SistemaAcademicoBD;
-- Uso de la base de datos
USE SistemaAcademicoBD;
-- generamos la clase estudiante 
CREATE TABLE IF NOT EXISTS Estudiante (
    Numero_Matricula VARCHAR(15) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Correo_Electronico VARCHAR(100) UNIQUE NOT NULL
);
-- aqui pondre la tabla de profesores
CREATE TABLE IF NOT EXISTS Profesores (
    Codigo_Profesores VARCHAR(10) PRIMARY KEY, 
    Nombre VARCHAR(100) NOT NULL,
    Especialidad VARCHAR(100)
);
-- la ultima tabla es del curso
CREATE TABLE IF NOT EXISTS Cursos (
    Id_Curso INT PRIMARY KEY,               
    Codigo_Curso VARCHAR(20) UNIQUE NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Numero_Credito INT,
    Codigo_Profesor VARCHAR(10),

    CONSTRAINT fk_cursos_profesor
        FOREIGN KEY (Codigo_Profesor) 
        REFERENCES Profesores(Codigo_Profesores)
        ON UPDATE CASCADE
        ON DELETE SET NULL 
);

CREATE TABLE IF NOT EXISTS Inscribe (
    -- Claves Foráneas que forman la Clave Primaria Compuesta
    Numero_Matricula VARCHAR(15) NOT NULL,
    Id_Curso INT NOT NULL,
    Fecha_Inscripcion DATE NOT NULL,
    
    PRIMARY KEY (Numero_Matricula, Id_Curso), 

    CONSTRAINT fk_inscribe_estudiante
        FOREIGN KEY (Numero_Matricula) REFERENCES Estudiante(Numero_Matricula)
        ON UPDATE CASCADE
        ON DELETE CASCADE, 
        
    CONSTRAINT fk_inscribe_cursos
        FOREIGN KEY (Id_Curso) REFERENCES Cursos(Id_Curso)
        ON UPDATE CASCADE
        ON DELETE CASCADE  
);