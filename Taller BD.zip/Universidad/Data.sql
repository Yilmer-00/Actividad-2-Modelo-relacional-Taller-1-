-- creamos la DATA para profesores
INSERT INTO Profesores (Codigo_Profesores, Nombre, Especialidad) VALUES
('P001', 'Dra. Elena Robles', 'Matemáticas Avanzadas'),
('P002', 'Ing. Carlos Sanz', 'Ingeniería de Software'),
('P003', 'Lic. Ana Gómez', 'Historia del Arte');

-- creamos la DATA para estudiantes
INSERT INTO Estudiante (Numero_Matricula, Nombre, Correo_Electronico) VALUES
('M1001', 'Juan Díaz', 'juan.diaz@uni.edu'),
('M1002', 'Sofía Castro', 'sofia.castro@uni.edu'),
('M1003', 'Pedro López', 'pedro.lopez@uni.edu');

-- creamos la DATA para cursos
INSERT INTO Cursos (Id_Curso, Codigo_Curso, Nombre, Numero_Credito, Codigo_Profesor) VALUES
(1, 'MAT101', 'Cálculo I', 4, 'P001'),
(2, 'ING205', 'Base de Datos', 3, 'P002'),
(3, 'ART301', 'Renacimiento', 2, 'P003'),
(4, 'MAT202', 'Álgebra Lineal', 4, 'P001');

-- creamos la DATA para Inscribe
INSERT INTO Inscribe (Numero_Matricula, Id_Curso, Fecha_Inscripcion) VALUES
('M1001', 1, '2025-08-15'), 
('M1001', 2, '2025-08-15'), 
('M1002', 3, '2025-08-16'),
('M1003', 2, '2025-08-16'),
('M1003', 4, '2025-08-16');